void fgrain(int MinArea, float *in, int nx, int ny, float *out);
